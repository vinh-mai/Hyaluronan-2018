# Hyaluronan-2018
Python programs that are used for calculating numerical solutions of ODEs, parameter estimate, and global sensitivity analysis. They include pe-ha.py and SA.py files.

- The pe-ha.py file is used for parameter estimation.
- The SA.py is used for implementing sensitivity analysis.


